'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Checkbox } from '@/components/ui/checkbox'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Camera, 
  Video, 
  Album, 
  User, 
  Calendar, 
  Plus, 
  Edit, 
  Save, 
  Trash2, 
  FileText,
  Search, 
  Settings, 
  Package, 
  DollarSign,
  Star,
  Clock,
  Users,
  MapPin,
  Phone,
  Mail,
  X,
  ChevronUp,
  Filter,
  Zap,
  Target,
  Sparkles,
  TrendingUp,
  Eye,
  Home,
  ChevronDown
} from 'lucide-react'

// Service categories
const SERVICE_CATEGORIES = [
  {
    id: 'photography',
    name: 'Photography',
    icon: Camera,
    color: 'bg-blue-100 text-blue-800',
    description: 'Professional photography services'
  },
  {
    id: 'videography',
    name: 'Videography',
    icon: Video,
    color: 'bg-purple-100 text-purple-800',
    description: 'Video recording and production'
  },
  {
    id: 'equipment',
    name: 'Equipment',
    icon: Settings,
    color: 'bg-green-100 text-green-800',
    description: 'Specialized equipment and gear'
  },
  {
    id: 'post-production',
    name: 'Post Production',
    icon: Sparkles,
    color: 'bg-orange-100 text-orange-800',
    description: 'Editing and enhancement services'
  }
]

// Default services
const DEFAULT_SERVICES = [
  {
    id: 'traditionalCamera',
    name: 'Traditional Camera',
    category: 'photography',
    description: 'Professional DSLR photography',
    basePrice: 15000,
    pricingModel: 'per-event',
    icon: Camera,
    features: ['High resolution images', 'Professional lighting', 'Multiple angles'],
    popular: true,
    recommended: true
  },
  {
    id: 'candidPhotography',
    name: 'Candid Photography',
    category: 'photography',
    description: 'Natural, unposed photography',
    basePrice: 25000,
    pricingModel: 'per-event',
    icon: Camera,
    features: ['Natural moments', 'Emotional captures', 'Storytelling'],
    popular: true,
    recommended: true
  },
  {
    id: 'fourKVideo',
    name: '4K Video Recording',
    category: 'videography',
    description: 'Ultra HD video recording',
    basePrice: 30000,
    pricingModel: 'per-event',
    icon: Video,
    features: ['4K resolution', 'Professional audio', 'Multi-camera setup'],
    popular: true,
    recommended: true
  },
  {
    id: 'ledScreens',
    name: 'LED Screens',
    category: 'equipment',
    description: 'Live event LED displays',
    basePrice: 20000,
    pricingModel: 'per-event',
    icon: Video,
    features: ['Live streaming', 'Guest viewing', 'Event enhancement'],
    popular: false,
    recommended: false
  },
  {
    id: 'drone',
    name: 'Drone Photography',
    category: 'equipment',
    description: 'Aerial photography and video',
    basePrice: 25000,
    pricingModel: 'per-event',
    icon: Video,
    features: ['Aerial views', 'Cinematic shots', 'Unique perspectives'],
    popular: true,
    recommended: false
  },
  {
    id: 'cinematicVideo',
    name: 'Cinematic Video',
    category: 'videography',
    description: 'Movie-style video production',
    basePrice: 40000,
    pricingModel: 'per-event',
    icon: Video,
    features: ['Cinematic grading', 'Professional editing', 'Storytelling'],
    popular: true,
    recommended: true
  }
]

// Default events
const DEFAULT_EVENTS = [
  { key: 'engagement', name: 'Engagement Ceremony', duration: '2-3 hours', typicalServices: ['traditionalCamera', 'candidPhotography', 'fourKVideo'] },
  { key: 'haldiBride', name: 'Haldi Ceremony - Bride', duration: '1-2 hours', typicalServices: ['traditionalCamera', 'fourKVideo'] },
  { key: 'haldiGroom', name: 'Haldi Ceremony - Groom', duration: '1-2 hours', typicalServices: ['traditionalCamera', 'fourKVideo'] },
  { key: 'wedding', name: 'Wedding Ceremony', duration: '4-6 hours', typicalServices: ['traditionalCamera', 'candidPhotography', 'fourKVideo', 'drone', 'cinematicVideo'] },
  { key: 'reception', name: 'Reception Party', duration: '3-5 hours', typicalServices: ['traditionalCamera', 'candidPhotography', 'fourKVideo', 'ledScreens'] }
]

// Album options
const ALBUM_OPTIONS = [
  { value: '200', label: '200 Sheets (100+100)', price: 50000 },
  { value: '300', label: '300 Sheets (150+150)', price: 75000 },
  { value: '400', label: '400 Sheets (200+200)', price: 100000 }
]

// Advanced packages
const ADVANCED_PACKAGES = [
  {
    id: 'basic',
    name: 'Essential Package',
    description: 'Perfect for intimate weddings',
    priceRange: '₹1.5L - ₹2.5L',
    events: ['engagement', 'wedding'],
    services: {
      engagement: ['traditionalCamera', 'fourKVideo'],
      wedding: ['traditionalCamera', 'candidPhotography', 'fourKVideo']
    },
    album: { sheets: '200', type: 'Light weight premium glossy albums' },
    includes: ['Basic editing', 'Online gallery', 'USB delivery'],
    popular: true
  },
  {
    id: 'premium',
    name: 'Premium Package',
    description: 'Complete coverage experience',
    priceRange: '₹3L - ₹4.5L',
    events: ['engagement', 'haldiBride', 'haldiGroom', 'wedding', 'reception'],
    services: {
      engagement: ['traditionalCamera', 'candidPhotography', 'fourKVideo'],
      haldiBride: ['traditionalCamera', 'fourKVideo'],
      haldiGroom: ['traditionalCamera', 'fourKVideo'],
      wedding: ['traditionalCamera', 'candidPhotography', 'fourKVideo', 'drone', 'cinematicVideo'],
      reception: ['traditionalCamera', 'candidPhotography', 'fourKVideo']
    },
    album: { sheets: '300', type: 'Premium leather albums' },
    includes: ['Advanced editing', 'Drone footage', 'Same day edits', 'Online gallery', 'USB + Cloud delivery'],
    popular: true
  },
  {
    id: 'luxury',
    name: 'Luxury Package',
    description: 'Ultimate wedding experience',
    priceRange: '₹5L - ₹7L',
    events: ['engagement', 'haldiBride', 'haldiGroom', 'wedding', 'reception'],
    services: {
      engagement: ['traditionalCamera', 'candidPhotography', 'fourKVideo', 'ledScreens'],
      haldiBride: ['traditionalCamera', 'candidPhotography', 'fourKVideo'],
      haldiGroom: ['traditionalCamera', 'candidPhotography', 'fourKVideo'],
      wedding: ['traditionalCamera', 'candidPhotography', 'fourKVideo', 'ledScreens', 'drone', 'cinematicVideo'],
      reception: ['traditionalCamera', 'candidPhotography', 'fourKVideo', 'ledScreens']
    },
    album: { sheets: '400', type: 'Luxury crystal albums' },
    includes: ['Luxury editing', 'Drone + LED screens', 'Same day edits', 'Highlight film', 'Online gallery', 'Premium album', 'USB + Cloud delivery'],
    popular: true
  }
]

interface Service {
  id: string
  name: string
  category: string
  description: string
  basePrice: number
  pricingModel: 'per-event' | 'hourly' | 'package' | 'custom'
  icon: any
  features: string[]
  popular: boolean
  recommended: boolean
  custom?: boolean
}

interface CustomEvent {
  key: string
  name: string
  duration?: string
  typicalServices?: string[]
}

interface QuotationData {
  customerName: string
  customerPhone: string
  customerEmail: string
  customerAddress: string
  eventLocation: string
  events: Record<string, Record<string, boolean>>
  albumSheets: string
  albumType: string
  additionalServices: Record<string, boolean>
  specialRequests: string
  discount: number
  notes: string
  customPricing: Record<string, number>
  bundles: string[]
}

interface SavedQuotation {
  id: string
  customerName: string
  customerPhone: string
  eventLocation: string
  totalCost: number
  createdAt: string
  quotationData: QuotationData
}

const createEmptyQuotationData = (): QuotationData => ({
  customerName: '',
  customerPhone: '',
  customerEmail: '',
  customerAddress: '',
  eventLocation: '',
  events: {},
  albumSheets: '200',
  albumType: 'Light weight premium glossy albums',
  additionalServices: {},
  specialRequests: '',
  discount: 0,
  notes: '',
  customPricing: {},
  bundles: []
})

export default function AdvancedQuotationGenerator() {
  const [quotationData, setQuotationData] = useState<QuotationData>(createEmptyQuotationData())
  const [showQuotation, setShowQuotation] = useState(false)
  const [totalCost, setTotalCost] = useState(0)
  const [services, setServices] = useState<Service[]>(DEFAULT_SERVICES)
  const [events, setEvents] = useState<CustomEvent[]>(DEFAULT_EVENTS)
  const [selectedEvents, setSelectedEvents] = useState<string[]>([])
  const [savedQuotations, setSavedQuotations] = useState<SavedQuotation[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [activeCategory, setActiveCategory] = useState<string>('all')
  const [activeTab, setActiveTab] = useState('overview')

  // Load saved data
  useEffect(() => {
    const saved = localStorage.getItem('sumuhurtham-quotations')
    if (saved) setSavedQuotations(JSON.parse(saved))
  }, [])

  // Auto-calculate when data changes
  useEffect(() => {
    if (Object.keys(quotationData.events).length > 0) {
      calculateTotal()
    }
  }, [quotationData, services])

  const formatPrice = (price: number) => {
    return `₹${price.toLocaleString('en-IN')}`
  }

  const calculateTotal = () => {
    let total = 0
    
    // Calculate event services
    Object.entries(quotationData.events).forEach(([eventKey, eventServices]) => {
      Object.entries(eventServices).forEach(([serviceId, isSelected]) => {
        if (isSelected) {
          const service = services.find(s => s.id === serviceId)
          if (service) {
            const price = quotationData.customPricing[serviceId] || service.basePrice
            total += price
          }
        }
      })
    })
    
    // Add albums cost
    const albumOption = ALBUM_OPTIONS.find(a => a.value === quotationData.albumSheets)
    if (albumOption) {
      total += albumOption.price
    }
    
    // Add transport cost if outside Hyderabad
    if (quotationData.eventLocation && 
        !quotationData.eventLocation.toLowerCase().includes('hyderabad')) {
      total += 25000
    }
    
    // Apply discount
    total = total * (1 - quotationData.discount / 100)
    
    setTotalCost(Math.round(total))
    return Math.round(total)
  }

  const updateCustomerField = (field: keyof QuotationData, value: string | number) => {
    setQuotationData(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const updateEventService = (eventKey: string, serviceId: string, checked: boolean) => {
    setQuotationData(prev => ({
      ...prev,
      events: {
        ...prev.events,
        [eventKey]: {
          ...prev.events[eventKey],
          [serviceId]: checked
        }
      }
    }))
  }

  const handleEventSelection = (eventKey: string, checked: boolean) => {
    if (checked) {
      setSelectedEvents(prev => [...prev, eventKey])
      if (!quotationData.events[eventKey]) {
        const eventServices: Record<string, boolean> = {}
        services.forEach(service => {
          eventServices[service.id] = false
        })
        setQuotationData(prev => ({
          ...prev,
          events: {
            ...prev.events,
            [eventKey]: eventServices
          }
        }))
      }
    } else {
      setSelectedEvents(prev => prev.filter(key => key !== eventKey))
    }
  }

  const applyAdvancedPackage = (pkg: any) => {
    const newEvents: Record<string, Record<string, boolean>> = {}
    
    // Initialize all events with empty services
    events.forEach(event => {
      newEvents[event.key] = {}
      services.forEach(service => {
        newEvents[event.key][service.id] = false
      })
    })
    
    // Apply package services
    Object.entries(pkg.services).forEach(([eventKey, serviceIds]) => {
      if (newEvents[eventKey]) {
        (serviceIds as string[]).forEach(serviceId => {
          newEvents[eventKey][serviceId] = true
        })
      }
    })
    
    setQuotationData(prev => ({
      ...prev,
      events: newEvents,
      albumSheets: pkg.album.sheets,
      albumType: pkg.album.type
    }))
    
    setSelectedEvents(pkg.events)
    setActiveTab('form')
  }

  const saveQuotation = () => {
    if (!quotationData.customerName || !quotationData.customerPhone || !quotationData.eventLocation) {
      alert('Please fill in all required fields: Name, Phone, and Event Location')
      return
    }
    
    const total = calculateTotal()
    const newQuotation: SavedQuotation = {
      id: Date.now().toString(),
      customerName: quotationData.customerName,
      customerPhone: quotationData.customerPhone,
      eventLocation: quotationData.eventLocation,
      totalCost: total,
      createdAt: new Date().toISOString(),
      quotationData: { ...quotationData }
    }
    
    const updated = [...savedQuotations, newQuotation]
    setSavedQuotations(updated)
    localStorage.setItem('sumuhurtham-quotations', JSON.stringify(updated))
    
    alert('Quotation saved successfully!')
  }

  const loadQuotation = (quotation: SavedQuotation) => {
    setQuotationData(quotation.quotationData)
    setSelectedEvents(Object.keys(quotation.quotationData.events))
    setShowQuotation(false)
    setActiveTab('form')
  }

  const deleteQuotation = (id: string) => {
    const updated = savedQuotations.filter(q => q.id !== id)
    setSavedQuotations(updated)
    localStorage.setItem('sumuhurtham-quotations', JSON.stringify(updated))
  }

  const generateQuotation = () => {
    if (!quotationData.customerName || !quotationData.customerPhone || !quotationData.eventLocation) {
      alert('Please fill in all required fields: Name, Phone, and Event Location')
      return
    }
    
    const total = calculateTotal()
    setShowQuotation(true)
    setActiveTab('quotation')
  }

  const resetForm = () => {
    setQuotationData(createEmptyQuotationData())
    setSelectedEvents([])
    setShowQuotation(false)
    setTotalCost(0)
  }

  const filteredServices = services.filter(service => {
    // Category filter
    if (activeCategory !== 'all' && service.category !== activeCategory) return false
    
    // Search filter
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase()
      const matchesName = service.name.toLowerCase().includes(searchLower)
      const matchesDescription = service.description.toLowerCase().includes(searchLower)
      const matchesFeatures = service.features.some(feature => 
        feature.toLowerCase().includes(searchLower)
      )
      const matchesCategory = service.category.toLowerCase().includes(searchLower)
      
      if (!matchesName && !matchesDescription && !matchesFeatures && !matchesCategory) {
        return false
      }
    }
    
    return true
  })

  const filteredQuotations = savedQuotations.filter(q =>
    q.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    q.customerPhone.includes(searchTerm) ||
    q.eventLocation.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Professional Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo and Brand */}
            <div className="flex items-center">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-slate-900 rounded-lg flex items-center justify-center">
                  <Camera className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-semibold text-slate-900">Sumuhurtham</h1>
                  <p className="text-xs text-slate-500">Wedding Photography Suite</p>
                </div>
              </div>
            </div>

            {/* Navigation */}
            <nav className="hidden md:flex items-center space-x-1">
              <button className="px-3 py-2 text-sm font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors">
                Dashboard
              </button>
              <button className="px-3 py-2 text-sm font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors">
                Quotations
              </button>
              <button className="px-3 py-2 text-sm font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors">
                Customers
              </button>
              <button className="px-3 py-2 text-sm font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors">
                Analytics
              </button>
            </nav>

            {/* User Menu */}
            <div className="flex items-center space-x-4">
              <button className="relative p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
                <Bell className="w-5 h-5" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-slate-200 rounded-full flex items-center justify-center">
                  <span className="text-sm font-medium text-slate-700">U</span>
                </div>
                <span className="hidden sm:block text-sm font-medium text-slate-700">Admin</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div>
        {/* Breadcrumb */}
        <nav className="flex items-center space-x-1 text-sm text-slate-500 mb-6">
          <a href="#" className="hover:text-slate-700">Home</a>
          <ChevronRight className="w-4 h-4" />
          <span className="text-slate-900">Quotation Manager</span>
        </nav>

        {/* Page Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">Quotation Management</h2>
              <p className="mt-1 text-sm text-slate-600">Create and manage wedding photography quotations</p>
            </div>
            <div className="flex items-center space-x-3">
              <button className="inline-flex items-center px-4 py-2 border border-slate-300 rounded-md shadow-sm text-sm font-medium text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-500">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </button>
              <button className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-500">
                <Plus className="w-4 h-4 mr-2" />
                New Quotation
              </button>
            </div>
          </div>
        </div>

        {/* Professional Tabs */}
        <div className="bg-white rounded-lg shadow-sm border border-slate-200">
          <div className="border-b border-slate-200">
            <nav className="flex -mb-px">
              {[
                { id: 'overview', label: 'Overview', icon: Home },
                { id: 'services', label: 'Services', icon: Camera },
                { id: 'packages', label: 'Packages', icon: Package },
                { id: 'form', label: 'Build Quote', icon: FileText },
                { id: 'saved', label: 'Saved', icon: Save, count: savedQuotations.length },
                { id: 'customers', label: 'Customers', icon: Users },
                { id: 'schedule', label: 'Schedule', icon: Calendar },
                { id: 'analytics', label: 'Analytics', icon: TrendingUp },
                { id: 'settings', label: 'Settings', icon: Settings },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`group inline-flex items-center py-4 px-6 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-slate-900 text-slate-900'
                      : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                  }`}
                >
                  <tab.icon className="w-4 h-4 mr-2" />
                  {tab.label}
                  {tab.count !== undefined && (
                    <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-900">
                      {tab.count}
                    </span>
                  )}
                </button>
              ))}
            </nav>
          </div>

          {/* Tab Content */}
          <div className="p-6">
          {/* Dashboard Tab */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white border border-slate-200 rounded-lg p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                      <FileText className="w-5 h-5 text-blue-600" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-slate-600">Total Quotations</p>
                    <p className="text-2xl font-semibold text-slate-900">{savedQuotations.length}</p>
                  </div>
                </div>
                <div className="mt-4">
                  <div className="flex items-center text-sm">
                    <span className="text-green-600 font-medium">+12.5%</span>
                    <span className="text-slate-500 ml-2">from last month</span>
                  </div>
                </div>
              </div>

              <div className="bg-white border border-slate-200 rounded-lg p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                      <Users className="w-5 h-5 text-green-600" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-slate-600">Active Customers</p>
                    <p className="text-2xl font-semibold text-slate-900">{new Set(savedQuotations.map(q => q.customerPhone)).size}</p>
                  </div>
                </div>
                <div className="mt-4">
                  <div className="flex items-center text-sm">
                    <span className="text-green-600 font-medium">+8.2%</span>
                    <span className="text-slate-500 ml-2">from last month</span>
                  </div>
                </div>
              </div>

              <div className="bg-white border border-slate-200 rounded-lg p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                      <Package className="w-5 h-5 text-purple-600" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-slate-600">Services</p>
                    <p className="text-2xl font-semibold text-slate-900">{services.length}</p>
                  </div>
                </div>
                <div className="mt-4">
                  <div className="flex items-center text-sm">
                    <span className="text-slate-500">All active</span>
                  </div>
                </div>
              </div>

              <div className="bg-white border border-slate-200 rounded-lg p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center">
                      <DollarSign className="w-5 h-5 text-orange-600" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-slate-600">Revenue</p>
                    <p className="text-2xl font-semibold text-slate-900">
                      {formatPrice(savedQuotations.reduce((sum, q) => sum + q.totalCost, 0))}
                    </p>
                  </div>
                </div>
                <div className="mt-4">
                  <div className="flex items-center text-sm">
                    <span className="text-green-600 font-medium">+23.1%</span>
                    <span className="text-slate-500 ml-2">from last month</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white border border-slate-200 rounded-lg p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-slate-900">Quick Actions</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <button 
                  onClick={() => setActiveTab('form')}
                  className="group relative bg-white border border-slate-200 rounded-lg p-6 text-left hover:shadow-md transition-all duration-200 hover:border-slate-300"
                >
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-200 transition-colors">
                        <FileText className="w-6 h-6 text-blue-600" />
                      </div>
                    </div>
                    <div className="ml-4">
                      <h4 className="text-base font-semibold text-slate-900">New Quotation</h4>
                      <p className="text-sm text-slate-500 mt-1">Create a new quote</p>
                    </div>
                  </div>
                </button>

                <button 
                  onClick={() => setActiveTab('services')}
                  className="group relative bg-white border border-slate-200 rounded-lg p-6 text-left hover:shadow-md transition-all duration-200 hover:border-slate-300"
                >
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center group-hover:bg-purple-200 transition-colors">
                        <Camera className="w-6 h-6 text-purple-600" />
                      </div>
                    </div>
                    <div className="ml-4">
                      <h4 className="text-base font-semibold text-slate-900">Manage Services</h4>
                      <p className="text-sm text-slate-500 mt-1">View and edit services</p>
                    </div>
                  </div>
                </button>

                <button 
                  onClick={() => setActiveTab('customers')}
                  className="group relative bg-white border border-slate-200 rounded-lg p-6 text-left hover:shadow-md transition-all duration-200 hover:border-slate-300"
                >
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center group-hover:bg-green-200 transition-colors">
                        <Users className="w-6 h-6 text-green-600" />
                      </div>
                    </div>
                    <div className="ml-4">
                      <h4 className="text-base font-semibold text-slate-900">Customers</h4>
                      <p className="text-sm text-slate-500 mt-1">Manage customers</p>
                    </div>
                  </div>
                </button>

                <button 
                  onClick={() => setActiveTab('analytics')}
                  className="group relative bg-white border border-slate-200 rounded-lg p-6 text-left hover:shadow-md transition-all duration-200 hover:border-slate-300"
                >
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center group-hover:bg-orange-200 transition-colors">
                        <TrendingUp className="w-6 h-6 text-orange-600" />
                      </div>
                    </div>
                    <div className="ml-4">
                      <h4 className="text-base font-semibold text-slate-900">Analytics</h4>
                      <p className="text-sm text-slate-500 mt-1">View reports</p>
                    </div>
                  </div>
                </button>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white border border-slate-200 rounded-lg p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold text-slate-900">Recent Quotations</h3>
                  <button 
                    onClick={() => setActiveTab('saved')}
                    className="text-sm font-medium text-blue-600 hover:text-blue-700"
                  >
                    View all
                  </button>
                </div>
                {savedQuotations.length === 0 ? (
                  <div className="text-center py-8">
                    <FileText className="w-12 h-12 mx-auto text-slate-300" />
                    <p className="mt-2 text-sm text-slate-500">No recent quotations</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {savedQuotations.slice(-3).reverse().map((quotation) => (
                      <div key={quotation.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-slate-200 rounded-full flex items-center justify-center">
                            <span className="text-sm font-medium text-slate-700">
                              {quotation.customerName.charAt(0).toUpperCase()}
                            </span>
                          </div>
                          <div className="ml-4">
                            <p className="text-sm font-medium text-slate-900">{quotation.customerName}</p>
                            <p className="text-xs text-slate-500">{quotation.eventLocation}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-semibold text-slate-900">{formatPrice(quotation.totalCost)}</p>
                          <p className="text-xs text-slate-500">
                            {new Date(quotation.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="bg-white border border-slate-200 rounded-lg p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold text-slate-900">System Status</h3>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                      <span className="text-sm text-slate-700">Application Status</span>
                    </div>
                    <span className="text-sm font-medium text-green-600">Operational</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                      <span className="text-sm text-slate-700">Database Connection</span>
                    </div>
                    <span className="text-sm font-medium text-green-600">Connected</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                      <span className="text-sm text-slate-700">Storage Usage</span>
                    </div>
                    <span className="text-sm font-medium text-blue-600">2.4 MB / 100 MB</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                      <span className="text-sm text-slate-700">Last Backup</span>
                    </div>
                    <span className="text-sm font-medium text-green-600">2 hours ago</span>
                  </div>
                </div>
              </div>
            </div>
          )}
          </div>

          {/* Services Tab */}
          {activeTab === 'services' && (
            <div className="space-y-6">
            {/* Services Header */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <h3 className="text-lg font-semibold text-slate-900">Service Management</h3>
                <p className="text-sm text-slate-600">Manage your photography and videography services</p>
              </div>
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search services..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500 w-64"
                  />
                </div>
                <button className="inline-flex items-center px-4 py-2 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-500">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Service
                </button>
              </div>
            </div>

            {/* Category Filters */}
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setActiveCategory('all')}
                className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
                  activeCategory === 'all'
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                All Services
              </button>
              {SERVICE_CATEGORIES.map((category) => (
                <button
                  key={category.id}
                  onClick={() => setActiveCategory(activeCategory === category.id ? 'all' : category.id)}
                  className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
                    activeCategory === category.id
                      ? 'bg-slate-900 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {category.name}
                </button>
              ))}
            </div>

            {/* Services Grid */}
            <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-200">
                <div className="flex items-center justify-between">
                  <div className="text-sm text-slate-600">
                    Showing {filteredServices.length} of {services.length} services
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
                      <Filter className="w-4 h-4" />
                    </button>
                    <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
                      <ChevronDown className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="divide-y divide-slate-200">
                {filteredServices.map((service) => (
                  <div key={service.id} className="p-6 hover:bg-slate-50 transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-4">
                        <div className="flex-shrink-0">
                          <div className="w-12 h-12 bg-slate-100 rounded-lg flex items-center justify-center">
                            <service.icon className="w-6 h-6 text-slate-600" />
                          </div>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="text-lg font-semibold text-slate-900">{service.name}</h4>
                            {service.popular && (
                              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                                Popular
                              </span>
                            )}
                            {service.recommended && (
                              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                Recommended
                              </span>
                            )}
                          </div>
                          <p className="text-sm text-slate-600 mb-3">{service.description}</p>
                          <div className="flex flex-wrap gap-2 mb-3">
                            {service.features.map((feature, index) => (
                              <span key={index} className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-slate-100 text-slate-700">
                                {feature}
                              </span>
                            ))}
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4 text-sm text-slate-600">
                              <span>Category: <span className="font-medium text-slate-900">{service.category}</span></span>
                              <span>Pricing: <span className="font-medium text-slate-900">{service.pricingModel}</span></span>
                            </div>
                            <div className="text-lg font-semibold text-slate-900">
                              {formatPrice(service.basePrice)}
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2 ml-4">
                        <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
                          <Edit className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Empty State */}
            {filteredServices.length === 0 && (
              <div className="bg-white border border-slate-200 rounded-lg p-12 text-center">
                <Camera className="w-12 h-12 mx-auto text-slate-300" />
                <h3 className="mt-2 text-sm font-medium text-slate-900">No services found</h3>
                <p className="mt-1 text-sm text-slate-500">Try adjusting your search or filter criteria</p>
              </div>
            )}
          </div>
          )}

          {/* Packages Tab */}
          {activeTab === 'packages' && (
            <div className="space-y-6">
            <Card className="border-0 shadow-lg bg-gradient-to-r from-purple-50 to-pink-50">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                  Wedding Packages
                </CardTitle>
                <CardDescription className="text-lg text-gray-600">
                  Choose from our carefully curated packages designed for every wedding style and budget
                </CardDescription>
              </CardHeader>
            </Card>

            {/* Packages Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {ADVANCED_PACKAGES.map((pkg) => (
                <Card key={pkg.id} className={`border-0 shadow-lg hover:shadow-xl transition-all relative overflow-hidden ${
                  pkg.popular ? 'ring-2 ring-purple-500' : ''
                }`}>
                  {pkg.popular && (
                    <div className="absolute top-0 right-0 bg-gradient-to-r from-purple-500 to-pink-500 text-white px-3 py-1 text-xs font-bold">
                      MOST POPULAR
                    </div>
                  )}
                  <CardHeader className="text-center pb-4">
                    <CardTitle className="text-xl font-bold">{pkg.name}</CardTitle>
                    <CardDescription>{pkg.description}</CardDescription>
                    <div className="text-2xl font-bold text-purple-600 mt-2">{pkg.priceRange}</div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">Events Covered:</h4>
                      <div className="space-y-1">
                        {pkg.events.map((eventKey) => {
                          const event = DEFAULT_EVENTS.find(e => e.key === eventKey)
                          return (
                            <div key={eventKey} className="flex items-center gap-2 text-sm">
                              <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                              {event?.name}
                            </div>
                          )
                        })}
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold mb-2">Includes:</h4>
                      <div className="space-y-1">
                        {pkg.includes.map((item, index) => (
                          <div key={index} className="flex items-center gap-2 text-sm">
                            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                            {item}
                          </div>
                        ))}
                      </div>
                    </div>

                    <Button 
                      onClick={() => applyAdvancedPackage(pkg)}
                      className="w-full mt-4 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                    >
                      Apply This Package
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Navigation Buttons */}
            <Card className="border-0 shadow-lg">
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row justify-between gap-4">
                  <Button 
                    onClick={() => setActiveTab('services')} 
                    variant="outline" 
                    className="flex items-center gap-2"
                  >
                    <ChevronUp className="w-4 h-4" />
                    Previous: Browse Services
                  </Button>
                  <div className="flex gap-2">
                    <Button 
                      onClick={() => setActiveTab('form')} 
                      className="shadow-lg bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700"
                    >
                      <FileText className="w-4 h-4 mr-2" />
                      Build Quote with Package
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Build Quote Tab */}
          <TabsContent value="form" className="space-y-6">
            {/* Customer Information */}
            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-pink-50 to-purple-50 rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5 text-pink-600" />
                  Customer Information
                </CardTitle>
                <CardDescription>Please provide your contact details</CardDescription>
              </CardHeader>
              <CardContent className="p-4 sm:p-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="customerName" className="flex items-center gap-2">
                      <User className="w-4 h-4" />
                      Full Name *
                    </Label>
                    <Input
                      id="customerName"
                      value={quotationData.customerName}
                      onChange={(e) => updateCustomerField('customerName', e.target.value)}
                      placeholder="Enter your full name"
                      className="transition-all focus:ring-2 focus:ring-pink-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="customerPhone" className="flex items-center gap-2">
                      <Phone className="w-4 h-4" />
                      Phone Number *
                    </Label>
                    <Input
                      id="customerPhone"
                      value={quotationData.customerPhone}
                      onChange={(e) => updateCustomerField('customerPhone', e.target.value)}
                      placeholder="Enter your phone number"
                      className="transition-all focus:ring-2 focus:ring-pink-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="customerEmail" className="flex items-center gap-2">
                      <Mail className="w-4 h-4" />
                      Email Address
                    </Label>
                    <Input
                      id="customerEmail"
                      type="email"
                      value={quotationData.customerEmail}
                      onChange={(e) => updateCustomerField('customerEmail', e.target.value)}
                      placeholder="Enter your email address"
                      className="transition-all focus:ring-2 focus:ring-pink-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="eventLocation" className="flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      Event Location *
                    </Label>
                    <Input
                      id="eventLocation"
                      value={quotationData.eventLocation}
                      onChange={(e) => updateCustomerField('eventLocation', e.target.value)}
                      placeholder="Enter event location"
                      className="transition-all focus:ring-2 focus:ring-pink-500"
                    />
                    {quotationData.eventLocation && !quotationData.eventLocation.toLowerCase().includes('hyderabad') && (
                      <p className="text-xs text-orange-600 mt-1">
                        Additional transport charges will apply for locations outside Hyderabad
                      </p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Event Selection */}
            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-blue-600" />
                  Event Selection
                </CardTitle>
                <CardDescription>Select the events for your wedding celebration</CardDescription>
              </CardHeader>
              <CardContent className="p-4 sm:p-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {events.map((event) => (
                    <div key={event.key} className="flex items-center space-x-3 p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                      <Checkbox
                        id={event.key}
                        checked={selectedEvents.includes(event.key)}
                        onCheckedChange={(checked) => handleEventSelection(event.key, checked as boolean)}
                        className="data-[state=checked]:bg-purple-600 data-[state=checked]:border-purple-600"
                      />
                      <div className="flex-1">
                        <Label htmlFor={event.key} className="font-medium cursor-pointer">
                          {event.name}
                        </Label>
                        <p className="text-sm text-gray-600">{event.duration}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Service Selection */}
            {selectedEvents.length > 0 && (
              <Card className="border-0 shadow-lg">
                <CardHeader className="bg-gradient-to-r from-green-50 to-blue-50 rounded-t-lg">
                  <CardTitle className="flex items-center gap-2">
                    <Camera className="w-5 h-5 text-green-600" />
                    Service Selection
                  </CardTitle>
                  <CardDescription>Choose services for each selected event</CardDescription>
                </CardHeader>
                <CardContent className="p-4 sm:p-6">
                  <div className="space-y-6">
                    {selectedEvents.map((eventKey) => {
                      const event = events.find(e => e.key === eventKey)
                      return (
                        <div key={eventKey} className="border rounded-lg p-4">
                          <h3 className="font-semibold mb-4 text-lg">{event?.name}</h3>
                          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                            {services.map((service) => (
                              <div key={service.id} className="flex items-center space-x-3 p-3 border rounded hover:bg-gray-50 transition-colors">
                                <Checkbox
                                  id={`${eventKey}-${service.id}`}
                                  checked={quotationData.events[eventKey]?.[service.id] || false}
                                  onCheckedChange={(checked) => updateEventService(eventKey, service.id, checked as boolean)}
                                  className="data-[state=checked]:bg-purple-600 data-[state=checked]:border-purple-600"
                                />
                                <div className="flex-1">
                                  <Label htmlFor={`${eventKey}-${service.id}`} className="font-medium cursor-pointer text-sm">
                                    {service.name}
                                  </Label>
                                  <p className="text-xs text-gray-600">{formatPrice(service.basePrice)}</p>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Album Selection */}
            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-orange-50 to-yellow-50 rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <Album className="w-5 h-5 text-orange-600" />
                  Album Selection
                </CardTitle>
                <CardDescription>Choose your wedding album package</CardDescription>
              </CardHeader>
              <CardContent className="p-4 sm:p-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {ALBUM_OPTIONS.map((option) => (
                    <div key={option.value} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="font-semibold">{option.label}</h3>
                        <div className="text-lg font-bold text-purple-600">{formatPrice(option.price)}</div>
                      </div>
                      <Button
                        variant={quotationData.albumSheets === option.value ? "default" : "outline"}
                        onClick={() => updateCustomerField('albumSheets', option.value)}
                        className="w-full"
                      >
                        {quotationData.albumSheets === option.value ? "Selected" : "Select"}
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Pricing Summary */}
            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5 text-green-600" />
                  Pricing Summary
                </CardTitle>
                <CardDescription>Review your quotation total</CardDescription>
              </CardHeader>
              <CardContent className="p-4 sm:p-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Subtotal:</span>
                    <span className="font-semibold">{formatPrice(totalCost / (1 - quotationData.discount / 100))}</span>
                  </div>
                  {quotationData.discount > 0 && (
                    <div className="flex justify-between items-center">
                      <span>Discount ({quotationData.discount}%):</span>
                      <span className="font-semibold text-red-600">-{formatPrice((totalCost / (1 - quotationData.discount / 100)) * (quotationData.discount / 100))}</span>
                    </div>
                  )}
                  <div className="border-t pt-4">
                    <div className="flex justify-between items-center">
                      <span className="text-lg font-semibold">Total Amount:</span>
                      <span className="text-2xl font-bold text-purple-600">{formatPrice(totalCost)}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <Card className="border-0 shadow-lg">
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button 
                    onClick={generateQuotation} 
                    size="lg" 
                    className="flex-1 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 shadow-lg"
                  >
                    Generate Professional Quotation
                  </Button>
                  <Button onClick={saveQuotation} variant="outline" size="lg" className="shadow-lg">
                    <Save className="w-4 h-4 mr-2" />
                    Save Quote
                  </Button>
                  <Button onClick={resetForm} variant="outline" size="lg" className="shadow-lg">
                    Reset Form
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Navigation Buttons */}
            <Card className="border-0 shadow-lg">
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row justify-between gap-4">
                  <Button 
                    onClick={() => setActiveTab('packages')} 
                    variant="outline" 
                    className="flex items-center gap-2"
                  >
                    <ChevronUp className="w-4 h-4" />
                    Previous: View Packages
                  </Button>
                  <div className="flex gap-2">
                    <Button onClick={saveQuotation} variant="outline" className="shadow-lg">
                      <Save className="w-4 h-4 mr-2" />
                      Save Quote
                    </Button>
                    <Button onClick={() => setActiveTab('saved')} className="shadow-lg bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700">
                      <Eye className="w-4 h-4 mr-2" />
                      View Saved Quotes
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Saved Quotes Tab */}
          <TabsContent value="saved" className="space-y-6">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Save className="w-5 h-5" />
                  Saved Quotations ({savedQuotations.length})
                </CardTitle>
                <CardDescription>Manage your saved quotations</CardDescription>
              </CardHeader>
              <CardContent>
                {savedQuotations.length === 0 ? (
                  <div className="text-center py-12">
                    <Save className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                    <h3 className="text-lg font-semibold text-gray-600 mb-2">No saved quotations</h3>
                    <p className="text-gray-500 mb-4">Create your first quotation to get started</p>
                    <Button onClick={() => setActiveTab('form')} className="bg-gradient-to-r from-purple-500 to-purple-600">
                      Create Quote
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {filteredQuotations.map((quotation) => (
                      <Card key={quotation.id} className="border hover:shadow-md transition-shadow">
                        <CardContent className="p-6">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                            <div className="flex-1">
                              <h3 className="font-semibold text-lg">{quotation.customerName}</h3>
                              <div className="flex flex-wrap items-center gap-4 mt-2 text-sm text-gray-600">
                                <span className="flex items-center gap-1">
                                  <Phone className="w-4 h-4" />
                                  {quotation.customerPhone}
                                </span>
                                <span className="flex items-center gap-1">
                                  <MapPin className="w-4 h-4" />
                                  {quotation.eventLocation}
                                </span>
                                <span className="flex items-center gap-1">
                                  <Calendar className="w-4 h-4" />
                                  {new Date(quotation.createdAt).toLocaleDateString()}
                                </span>
                              </div>
                            </div>
                            <div className="flex items-center gap-3">
                              <div className="text-right">
                                <div className="text-2xl font-bold text-purple-600">{formatPrice(quotation.totalCost)}</div>
                                <div className="text-xs text-gray-500">Total Amount</div>
                              </div>
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => loadQuotation(quotation)}
                                >
                                  <Edit className="w-4 h-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => deleteQuotation(quotation.id)}
                                  className="text-red-600 hover:text-red-700"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Navigation Buttons */}
            <Card className="border-0 shadow-lg">
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row justify-between gap-4">
                  <Button 
                    onClick={() => setActiveTab('form')} 
                    variant="outline" 
                    className="flex items-center gap-2"
                  >
                    <ChevronUp className="w-4 h-4" />
                    Previous: Build Quote
                  </Button>
                  <div className="flex gap-2">
                    <Button 
                      onClick={() => setActiveTab('overview')} 
                      className="shadow-lg bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
                    >
                      <Home className="w-4 h-4 mr-2" />
                      Back to Dashboard
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Other Tabs (Simplified) */}
          <TabsContent value="customers" className="space-y-6">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Customer Management
                </CardTitle>
                <CardDescription>Manage customer information and view quotation history</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Customer Statistics */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card className="border-0 shadow-sm">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                            <Users className="w-5 h-5 text-blue-600" />
                          </div>
                          <div>
                            <div className="text-2xl font-bold text-blue-600">{new Set(savedQuotations.map(q => q.customerPhone)).size}</div>
                            <div className="text-sm text-gray-600">Total Customers</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    <Card className="border-0 shadow-sm">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                            <FileText className="w-5 h-5 text-green-600" />
                          </div>
                          <div>
                            <div className="text-2xl font-bold text-green-600">{savedQuotations.length}</div>
                            <div className="text-sm text-gray-600">Total Quotations</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    <Card className="border-0 shadow-sm">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                            <DollarSign className="w-5 h-5 text-purple-600" />
                          </div>
                          <div>
                            <div className="text-2xl font-bold text-purple-600">
                              {formatPrice(savedQuotations.reduce((sum, q) => sum + q.totalCost, 0))}
                            </div>
                            <div className="text-sm text-gray-600">Total Value</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Customer List */}
                  {savedQuotations.length === 0 ? (
                    <div className="text-center py-12">
                      <Users className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                      <h3 className="text-lg font-semibold text-gray-600 mb-2">No customers yet</h3>
                      <p className="text-gray-500 mb-4">Create your first quotation to get started</p>
                      <Button onClick={() => setActiveTab('form')} className="bg-gradient-to-r from-purple-500 to-purple-600">
                        Create Quote
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h3 className="text-lg font-semibold">Customer Directory</h3>
                        <div className="flex items-center gap-2">
                          <Input
                            placeholder="Search customers..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-64"
                          />
                          <Button variant="outline" size="sm">
                            <Filter className="w-4 h-4 mr-2" />
                            Filter
                          </Button>
                        </div>
                      </div>
                      
                      <div className="grid gap-4">
                        {Array.from(new Set(savedQuotations.map(q => q.customerPhone))).map(phone => {
                          const customerQuotes = savedQuotations.filter(q => q.customerPhone === phone)
                          const customer = customerQuotes[0]
                          return (
                            <Card key={phone} className="border hover:shadow-md transition-shadow">
                              <CardContent className="p-6">
                                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                                  <div className="flex-1">
                                    <div className="flex items-center gap-3 mb-2">
                                      <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                                        <span className="text-white font-semibold text-lg">
                                          {customer.customerName.charAt(0).toUpperCase()}
                                        </span>
                                      </div>
                                      <div>
                                        <h3 className="font-semibold text-lg">{customer.customerName}</h3>
                                        <p className="text-sm text-gray-600">{customer.customerEmail || 'No email provided'}</p>
                                      </div>
                                    </div>
                                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                                      <div className="flex items-center gap-2">
                                        <Phone className="w-4 h-4 text-gray-500" />
                                        <span>{phone}</span>
                                      </div>
                                      <div className="flex items-center gap-2">
                                        <MapPin className="w-4 h-4 text-gray-500" />
                                        <span>{customer.eventLocation}</span>
                                      </div>
                                      <div className="flex items-center gap-2">
                                        <FileText className="w-4 h-4 text-gray-500" />
                                        <span>{customerQuotes.length} quotation(s)</span>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-4">
                                    <div className="text-right">
                                      <div className="text-lg font-bold text-purple-600">
                                        {formatPrice(customerQuotes.reduce((sum, q) => sum + q.totalCost, 0))}
                                      </div>
                                      <div className="text-xs text-gray-500">Total Value</div>
                                    </div>
                                    <div className="flex gap-2">
                                      <Button
                                        size="sm"
                                        variant="outline"
                                        onClick={() => {
                                          loadQuotation(customerQuotes[customerQuotes.length - 1])
                                          setActiveTab('form')
                                        }}
                                      >
                                        <Edit className="w-4 h-4" />
                                      </Button>
                                      <Button
                                        size="sm"
                                        variant="outline"
                                        onClick={() => {
                                          setActiveTab('saved')
                                          setSearchTerm(phone)
                                        }}
                                      >
                                        <Eye className="w-4 h-4" />
                                      </Button>
                                    </div>
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          )
                        })}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="schedule" className="space-y-6">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5" />
                  Schedule Management
                </CardTitle>
                <CardDescription>Manage your photography schedule and resource allocation</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Schedule Statistics */}
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <Card className="border-0 shadow-sm">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                            <Calendar className="w-5 h-5 text-blue-600" />
                          </div>
                          <div>
                            <div className="text-2xl font-bold text-blue-600">{savedQuotations.length}</div>
                            <div className="text-sm text-gray-600">Booked Events</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    <Card className="border-0 shadow-sm">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                            <Camera className="w-5 h-5 text-green-600" />
                          </div>
                          <div>
                            <div className="text-2xl font-bold text-green-600">
                              {savedQuotations.reduce((sum, q) => sum + Object.keys(q.quotationData.events).length, 0)}
                            </div>
                            <div className="text-sm text-gray-600">Total Sessions</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    <Card className="border-0 shadow-sm">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                            <MapPin className="w-5 h-5 text-purple-600" />
                          </div>
                          <div>
                            <div className="text-2xl font-bold text-purple-600">
                              {new Set(savedQuotations.map(q => q.eventLocation)).size}
                            </div>
                            <div className="text-sm text-gray-600">Locations</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    <Card className="border-0 shadow-sm">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                            <Users className="w-5 h-5 text-orange-600" />
                          </div>
                          <div>
                            <div className="text-2xl font-bold text-orange-600">
                              {new Set(savedQuotations.map(q => q.customerPhone)).size}
                            </div>
                            <div className="text-sm text-gray-600">Clients</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Upcoming Events */}
                  <Card className="border-0 shadow-sm">
                    <CardHeader>
                      <CardTitle className="text-lg">Upcoming Events</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {savedQuotations.length === 0 ? (
                        <div className="text-center py-8">
                          <Calendar className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                          <p className="text-gray-500">No upcoming events scheduled</p>
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {savedQuotations.slice(-5).reverse().map((quotation) => (
                            <div key={quotation.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                              <div className="flex items-center gap-4">
                                <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                                  <Camera className="w-5 h-5 text-white" />
                                </div>
                                <div>
                                  <h4 className="font-semibold">{quotation.customerName}</h4>
                                  <p className="text-sm text-gray-600">{quotation.eventLocation}</p>
                                </div>
                              </div>
                              <div className="text-right">
                                <div className="font-semibold text-purple-600">{formatPrice(quotation.totalCost)}</div>
                                <div className="text-xs text-gray-500">
                                  {Object.keys(quotation.quotationData.events).length} event(s)
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  {/* Calendar View */}
                  <Card className="border-0 shadow-sm">
                    <CardHeader>
                      <CardTitle className="text-lg">Event Calendar</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="bg-gray-50 rounded-lg p-6">
                        <div className="text-center mb-4">
                          <h3 className="text-lg font-semibold mb-2">Interactive Calendar</h3>
                          <p className="text-gray-600">View and manage your photography schedule</p>
                        </div>
                        <div className="grid grid-cols-7 gap-2 mb-4">
                          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                            <div key={day} className="text-center font-semibold text-sm text-gray-600 p-2">
                              {day}
                            </div>
                          ))}
                          {Array.from({ length: 35 }, (_, i) => {
                            const day = i - 2 + 1 // Start from current week
                            const hasEvent = savedQuotations.length > 0 && Math.random() > 0.7
                            return (
                              <div
                                key={i}
                                className={`h-16 border rounded-lg p-1 text-sm cursor-pointer hover:bg-gray-100 ${
                                  day > 0 && day <= 31 ? 'bg-white' : 'bg-gray-100 text-gray-400'
                                }`}
                              >
                                {day > 0 && day <= 31 && (
                                  <>
                                    <div className="font-semibold">{day}</div>
                                    {hasEvent && (
                                      <div className="w-2 h-2 bg-purple-500 rounded-full mx-auto mt-1"></div>
                                    )}
                                  </>
                                )}
                              </div>
                            )
                          })}
                        </div>
                        <div className="flex justify-center gap-4 text-sm">
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
                            <span>Scheduled Events</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Quick Actions */}
                  <Card className="border-0 shadow-sm">
                    <CardHeader>
                      <CardTitle className="text-lg">Quick Actions</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <Button 
                          onClick={() => setActiveTab('form')} 
                          className="h-auto p-4 flex flex-col items-center gap-2"
                        >
                          <Plus className="w-6 h-6" />
                          <span>Schedule New Event</span>
                        </Button>
                        <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
                          <Calendar className="w-6 h-6" />
                          <span>View Full Calendar</span>
                        </Button>
                        <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
                          <Filter className="w-6 h-6" />
                          <span>Filter by Location</span>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Analytics Dashboard
                </CardTitle>
                <CardDescription>View business insights and performance metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Key Performance Indicators */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <Card className="border-0 shadow-sm">
                      <CardHeader className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-t-lg">
                        <CardTitle className="text-sm font-medium text-blue-800">Revenue</CardTitle>
                      </CardHeader>
                      <CardContent className="p-4">
                        <div className="text-2xl font-bold text-blue-600">
                          {formatPrice(savedQuotations.reduce((sum, q) => sum + q.totalCost, 0))}
                        </div>
                        <div className="text-xs text-gray-600 mt-1">Total Revenue</div>
                        <div className="flex items-center gap-1 mt-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span className="text-xs text-green-600">+12.5% from last month</span>
                        </div>
                      </CardContent>
                    </Card>
                    <Card className="border-0 shadow-sm">
                      <CardHeader className="bg-gradient-to-r from-green-50 to-green-100 rounded-t-lg">
                        <CardTitle className="text-sm font-medium text-green-800">Conversion Rate</CardTitle>
                      </CardHeader>
                      <CardContent className="p-4">
                        <div className="text-2xl font-bold text-green-600">78%</div>
                        <div className="text-xs text-gray-600 mt-1">Quote to Booking</div>
                        <div className="flex items-center gap-1 mt-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span className="text-xs text-green-600">+5.2% improvement</span>
                        </div>
                      </CardContent>
                    </Card>
                    <Card className="border-0 shadow-sm">
                      <CardHeader className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-t-lg">
                        <CardTitle className="text-sm font-medium text-purple-800">Average Order Value</CardTitle>
                      </CardHeader>
                      <CardContent className="p-4">
                        <div className="text-2xl font-bold text-purple-600">
                          {savedQuotations.length > 0 ? formatPrice(savedQuotations.reduce((sum, q) => sum + q.totalCost, 0) / savedQuotations.length) : '₹0'}
                        </div>
                        <div className="text-xs text-gray-600 mt-1">Per Quotation</div>
                        <div className="flex items-center gap-1 mt-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span className="text-xs text-green-600">+8.1% increase</span>
                        </div>
                      </CardContent>
                    </Card>
                    <Card className="border-0 shadow-sm">
                      <CardHeader className="bg-gradient-to-r from-orange-50 to-orange-100 rounded-t-lg">
                        <CardTitle className="text-sm font-medium text-orange-800">Customer Satisfaction</CardTitle>
                      </CardHeader>
                      <CardContent className="p-4">
                        <div className="text-2xl font-bold text-orange-600">4.8</div>
                        <div className="text-xs text-gray-600 mt-1">Average Rating</div>
                        <div className="flex items-center gap-1 mt-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span className="text-xs text-green-600">+0.3 improvement</span>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Revenue Chart */}
                  <Card className="border-0 shadow-sm">
                    <CardHeader>
                      <CardTitle className="text-lg">Revenue Overview</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="bg-gray-50 rounded-lg p-6">
                        <div className="text-center mb-4">
                          <h3 className="text-lg font-semibold mb-2">Monthly Revenue Trend</h3>
                          <p className="text-gray-600">Track your business growth over time</p>
                        </div>
                        <div className="h-64 flex items-end justify-between gap-2">
                          {[
                            { month: 'Jan', revenue: 250000 },
                            { month: 'Feb', revenue: 320000 },
                            { month: 'Mar', revenue: 280000 },
                            { month: 'Apr', revenue: 410000 },
                            { month: 'May', revenue: 380000 },
                            { month: 'Jun', revenue: 450000 },
                            { month: 'Jul', revenue: 520000 },
                          ].map((item, index) => (
                            <div key={item.month} className="flex-1 flex flex-col items-center">
                              <div
                                className="w-full bg-gradient-to-t from-purple-500 to-purple-300 rounded-t-lg"
                                style={{ height: `${(item.revenue / 600000) * 100}%` }}
                              ></div>
                              <div className="text-xs mt-2 text-gray-600">{item.month}</div>
                              <div className="text-xs text-purple-600 font-semibold">
                                {formatPrice(item.revenue)}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Service Popularity */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <Card className="border-0 shadow-sm">
                      <CardHeader>
                        <CardTitle className="text-lg">Service Popularity</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {[
                            { service: 'Traditional Photography', percentage: 85, color: 'bg-blue-500' },
                            { service: 'Candid Photography', percentage: 78, color: 'bg-purple-500' },
                            { service: '4K Video Recording', percentage: 72, color: 'bg-green-500' },
                            { service: 'Cinematic Video', percentage: 65, color: 'bg-orange-500' },
                            { service: 'Drone Photography', percentage: 45, color: 'bg-pink-500' },
                          ].map((item, index) => (
                            <div key={index} className="space-y-2">
                              <div className="flex justify-between items-center">
                                <span className="text-sm font-medium">{item.service}</span>
                                <span className="text-sm text-gray-600">{item.percentage}%</span>
                              </div>
                              <div className="w-full bg-gray-200 rounded-full h-2">
                                <div
                                  className={`h-2 rounded-full ${item.color}`}
                                  style={{ width: `${item.percentage}%` }}
                                ></div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="border-0 shadow-sm">
                      <CardHeader>
                        <CardTitle className="text-lg">Location Distribution</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="bg-gray-50 rounded-lg p-6">
                          <div className="text-center mb-4">
                            <h3 className="text-lg font-semibold mb-2">Top Locations</h3>
                            <p className="text-gray-600">Where your clients are located</p>
                          </div>
                          <div className="space-y-3">
                            {[
                              { location: 'Hyderabad', count: 12, percentage: 60 },
                              { location: 'Nellore', count: 5, percentage: 25 },
                              { location: 'Vijayawada', count: 2, percentage: 10 },
                              { location: 'Others', count: 1, percentage: 5 },
                            ].map((item, index) => (
                              <div key={index} className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                  <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                                    <MapPin className="w-4 h-4 text-white" />
                                  </div>
                                  <div>
                                    <div className="font-medium">{item.location}</div>
                                    <div className="text-xs text-gray-600">{item.count} clients</div>
                                  </div>
                                </div>
                                <div className="text-right">
                                  <div className="font-semibold text-purple-600">{item.percentage}%</div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Performance Metrics */}
                  <Card className="border-0 shadow-sm">
                    <CardHeader>
                      <CardTitle className="text-lg">Performance Metrics</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="text-center">
                          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <Users className="w-8 h-8 text-blue-600" />
                          </div>
                          <h3 className="font-semibold mb-1">Customer Growth</h3>
                          <p className="text-2xl font-bold text-blue-600">+23%</p>
                          <p className="text-sm text-gray-600">vs last quarter</p>
                        </div>
                        <div className="text-center">
                          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <FileText className="w-8 h-8 text-green-600" />
                          </div>
                          <h3 className="font-semibold mb-1">Quote Volume</h3>
                          <p className="text-2xl font-bold text-green-600">+18%</p>
                          <p className="text-sm text-gray-600">vs last quarter</p>
                        </div>
                        <div className="text-center">
                          <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <TrendingUp className="w-8 h-8 text-purple-600" />
                          </div>
                          <h3 className="font-semibold mb-1">Revenue Growth</h3>
                          <p className="text-2xl font-bold text-purple-600">+31%</p>
                          <p className="text-sm text-gray-600">vs last quarter</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  Advanced Settings
                </CardTitle>
                <CardDescription>Configure your quotation system</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Business Information */}
                  <Card className="border-0 shadow-sm">
                    <CardHeader>
                      <CardTitle className="text-lg">Business Information</CardTitle>
                      <CardDescription>Update your business details</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="businessName">Business Name</Label>
                          <Input
                            id="businessName"
                            defaultValue="Sumuhurtham Photography"
                            placeholder="Enter business name"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="businessPhone">Business Phone</Label>
                          <Input
                            id="businessPhone"
                            defaultValue="+91 99999 99999"
                            placeholder="Enter business phone"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="businessEmail">Business Email</Label>
                          <Input
                            id="businessEmail"
                            defaultValue="info@sumuhurtham.com"
                            placeholder="Enter business email"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="businessAddress">Business Address</Label>
                          <Input
                            id="businessAddress"
                            defaultValue="Hyderabad, Telangana"
                            placeholder="Enter business address"
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Pricing Settings */}
                  <Card className="border-0 shadow-sm">
                    <CardHeader>
                      <CardTitle className="text-lg">Pricing Settings</CardTitle>
                      <CardDescription>Configure default pricing and discounts</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="transportFee">Transport Fee (Outside Hyderabad)</Label>
                          <Input
                            id="transportFee"
                            type="number"
                            defaultValue="25000"
                            placeholder="Enter transport fee"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="defaultDiscount">Default Discount (%)</Label>
                          <Input
                            id="defaultDiscount"
                            type="number"
                            defaultValue="0"
                            placeholder="Enter default discount"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="currency">Currency</Label>
                          <Select defaultValue="INR">
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="INR">Indian Rupee (₹)</SelectItem>
                              <SelectItem value="USD">US Dollar ($)</SelectItem>
                              <SelectItem value="EUR">Euro (€)</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Service Management */}
                  <Card className="border-0 shadow-sm">
                    <CardHeader>
                      <CardTitle className="text-lg">Service Management</CardTitle>
                      <CardDescription>Manage your photography services</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <h3 className="font-medium">Available Services</h3>
                          <Button size="sm">
                            <Plus className="w-4 h-4 mr-2" />
                            Add Service
                          </Button>
                        </div>
                        <div className="space-y-3">
                          {services.map((service) => (
                            <div key={service.id} className="flex items-center justify-between p-4 border rounded-lg">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 bg-gradient-to-r from-blue-100 to-purple-100 rounded-lg flex items-center justify-center">
                                  <service.icon className="w-5 h-5 text-purple-600" />
                                </div>
                                <div>
                                  <h4 className="font-medium">{service.name}</h4>
                                  <p className="text-sm text-gray-600">{service.description}</p>
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="font-semibold text-purple-600">{formatPrice(service.basePrice)}</span>
                                <Button size="sm" variant="outline">
                                  <Edit className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Notification Settings */}
                  <Card className="border-0 shadow-sm">
                    <CardHeader>
                      <CardTitle className="text-lg">Notification Settings</CardTitle>
                      <CardDescription>Configure email and SMS notifications</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-medium">Email Notifications</h4>
                            <p className="text-sm text-gray-600">Send email notifications for new quotes</p>
                          </div>
                          <Checkbox defaultChecked />
                        </div>
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-medium">SMS Notifications</h4>
                            <p className="text-sm text-gray-600">Send SMS notifications for urgent updates</p>
                          </div>
                          <Checkbox />
                        </div>
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-medium">Auto-reminders</h4>
                            <p className="text-sm text-gray-600">Send automatic reminders to clients</p>
                          </div>
                          <Checkbox defaultChecked />
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Data Management */}
                  <Card className="border-0 shadow-sm">
                    <CardHeader>
                      <CardTitle className="text-lg">Data Management</CardTitle>
                      <CardDescription>Manage your data and backups</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
                          <Save className="w-6 h-6" />
                          <span>Export Data</span>
                        </Button>
                        <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
                          <FileText className="w-6 h-6" />
                          <span>Import Data</span>
                        </Button>
                      </div>
                      <div className="pt-4 border-t">
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-medium text-red-600">Clear All Data</h4>
                            <p className="text-sm text-gray-600">Permanently delete all quotations and customer data</p>
                          </div>
                          <Button variant="destructive" size="sm">
                            <Trash2 className="w-4 h-4 mr-2" />
                            Clear Data
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Save Settings */}
                  <Card className="border-0 shadow-sm">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">Save Changes</h3>
                          <p className="text-sm text-gray-600">All settings will be saved automatically</p>
                        </div>
                        <Button className="bg-gradient-to-r from-purple-500 to-purple-600">
                          <Save className="w-4 h-4 mr-2" />
                          Save Settings
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Professional Quotation Display */}
          <TabsContent value="quotation" className="space-y-6">
            {showQuotation && (
              <Card className="border-0 shadow-lg">
                <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                        Professional Quotation
                      </CardTitle>
                      <CardDescription className="text-lg">
                        Wedding Photography & Cinematography Services
                      </CardDescription>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-gray-600">Quotation ID</div>
                      <div className="font-mono text-lg font-semibold">#{Date.now().toString().slice(-6)}</div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-8">
                  <div className="space-y-8">
                    {/* Customer Information */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div>
                        <h3 className="text-lg font-semibold mb-4 text-purple-600">Customer Details</h3>
                        <div className="space-y-3">
                          <div className="flex justify-between">
                            <span className="text-gray-600">Name:</span>
                            <span className="font-medium">{quotationData.customerName}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Phone:</span>
                            <span className="font-medium">{quotationData.customerPhone}</span>
                          </div>
                          {quotationData.customerEmail && (
                            <div className="flex justify-between">
                              <span className="text-gray-600">Email:</span>
                              <span className="font-medium">{quotationData.customerEmail}</span>
                            </div>
                          )}
                          <div className="flex justify-between">
                            <span className="text-gray-600">Event Location:</span>
                            <span className="font-medium">{quotationData.eventLocation}</span>
                          </div>
                        </div>
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold mb-4 text-purple-600">Quotation Summary</h3>
                        <div className="space-y-3">
                          <div className="flex justify-between">
                            <span className="text-gray-600">Date:</span>
                            <span className="font-medium">{new Date().toLocaleDateString()}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Valid Until:</span>
                            <span className="font-medium">{new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString()}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Total Events:</span>
                            <span className="font-medium">{Object.keys(quotationData.events).length}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Album Sheets:</span>
                            <span className="font-medium">{quotationData.albumSheets}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Event-wise Services */}
                    <div>
                      <h3 className="text-lg font-semibold mb-4 text-purple-600">Event-wise Services</h3>
                      <div className="space-y-6">
                        {Object.entries(quotationData.events).map(([eventKey, eventServices]) => {
                          const event = events.find(e => e.key === eventKey)
                          if (!event) return null
                          
                          const selectedServices = Object.entries(eventServices)
                            .filter(([_, selected]) => selected)
                            .map(([serviceId, _]) => services.find(s => s.id === serviceId))
                            .filter(Boolean)
                          
                          if (selectedServices.length === 0) return null
                          
                          return (
                            <div key={eventKey} className="border rounded-lg p-4">
                              <h4 className="font-semibold text-lg mb-3">{event.name}</h4>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                {selectedServices.map((service) => (
                                  <div key={service?.id} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                                    <span className="font-medium">{service?.name}</span>
                                    <span className="text-purple-600 font-semibold">{formatPrice(service?.basePrice || 0)}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )
                        })}
                      </div>
                    </div>

                    {/* Album Details */}
                    <div>
                      <h3 className="text-lg font-semibold mb-4 text-purple-600">Album Package</h3>
                      <div className="border rounded-lg p-4">
                        <div className="flex justify-between items-center">
                          <div>
                            <h4 className="font-semibold">{quotationData.albumType}</h4>
                            <p className="text-gray-600">{quotationData.albumSheets} sheets total</p>
                          </div>
                          <span className="text-purple-600 font-semibold">
                            {formatPrice(ALBUM_OPTIONS.find(a => a.value === quotationData.albumSheets)?.price || 0)}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Additional Services */}
                    {quotationData.specialRequests && (
                      <div>
                        <h3 className="text-lg font-semibold mb-4 text-purple-600">Special Requests</h3>
                        <div className="border rounded-lg p-4 bg-gray-50">
                          <p className="text-gray-700">{quotationData.specialRequests}</p>
                        </div>
                      </div>
                    )}

                    {/* Pricing Breakdown */}
                    <div>
                      <h3 className="text-lg font-semibold mb-4 text-purple-600">Pricing Breakdown</h3>
                      <div className="border rounded-lg p-6 bg-gradient-to-r from-purple-50 to-pink-50">
                        <div className="space-y-3">
                          <div className="flex justify-between">
                            <span>Services Subtotal:</span>
                            <span className="font-semibold">
                              {formatPrice(totalCost / (1 - quotationData.discount / 100) - (ALBUM_OPTIONS.find(a => a.value === quotationData.albumSheets)?.price || 0))}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span>Album Package:</span>
                            <span className="font-semibold">
                              {formatPrice(ALBUM_OPTIONS.find(a => a.value === quotationData.albumSheets)?.price || 0)}
                            </span>
                          </div>
                          {quotationData.eventLocation && !quotationData.eventLocation.toLowerCase().includes('hyderabad') && (
                            <div className="flex justify-between">
                              <span>Transport Charges:</span>
                              <span className="font-semibold">₹25,000</span>
                            </div>
                          )}
                          {quotationData.discount > 0 && (
                            <div className="flex justify-between text-red-600">
                              <span>Discount ({quotationData.discount}%):</span>
                              <span className="font-semibold">
                                -{formatPrice((totalCost / (1 - quotationData.discount / 100)) * (quotationData.discount / 100))}
                              </span>
                            </div>
                          )}
                          <div className="border-t pt-3 mt-3">
                            <div className="flex justify-between items-center">
                              <span className="text-xl font-bold">Total Amount:</span>
                              <span className="text-2xl font-bold text-purple-600">{formatPrice(totalCost)}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Terms and Conditions */}
                    <div>
                      <h3 className="text-lg font-semibold mb-4 text-purple-600">Terms and Conditions</h3>
                      <div className="border rounded-lg p-4 bg-gray-50 text-sm text-gray-600">
                        <ul className="space-y-2 list-disc list-inside">
                          <li>50% advance payment required to confirm the booking</li>
                          <li>Remaining payment to be made on the event day</li>
                          <li>Prices are inclusive of basic editing and post-production</li>
                          <li>Additional charges apply for locations outside Hyderabad</li>
                          <li>Delivery timeline: 30-45 days after the event</li>
                          <li>Raw files will be provided as per package inclusions</li>
                        </ul>
                      </div>
                    </div>

                    {/* Contact Information */}
                    <div className="border-t pt-6">
                      <div className="text-center">
                        <h3 className="text-lg font-semibold mb-2">Sumuhurtham Photography</h3>
                        <p className="text-gray-600 mb-2">Professional Wedding Photography & Cinematography</p>
                        <div className="flex justify-center gap-4 text-sm text-gray-600">
                          <span>📞 +91 99999 99999</span>
                          <span>📧 info@sumuhurtham.com</span>
                          <span>📍 Hyderabad, Telangana</span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex flex-col sm:flex-row gap-4 pt-6 border-t">
                      <Button 
                        onClick={() => window.print()} 
                        variant="outline" 
                        size="lg"
                        className="flex-1"
                      >
                        <Save className="w-4 h-4 mr-2" />
                        Print Quotation
                      </Button>
                      <Button 
                        onClick={saveQuotation} 
                        size="lg"
                        className="flex-1 bg-gradient-to-r from-purple-500 to-purple-600"
                      >
                        <Save className="w-4 h-4 mr-2" />
                        Save Quotation
                      </Button>
                      <Button 
                        onClick={() => setShowQuotation(false)} 
                        variant="outline" 
                        size="lg"
                        className="flex-1"
                      >
                        <Edit className="w-4 h-4 mr-2" />
                        Edit Quote
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
          </div>
        </div>
        </div>
        </div>
      </div>
      </main>
  )
}