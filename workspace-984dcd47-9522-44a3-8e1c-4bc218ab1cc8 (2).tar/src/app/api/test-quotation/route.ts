import { NextRequest, NextResponse } from 'next/server'

// Service pricing
const PRICES = {
  traditionalCamera: 15000,
  candidPhotography: 25000,
  fourKVideo: 30000,
  ledScreens: 20000,
  drone: 25000,
  cinematicVideo: 40000,
  albums: 50000,
  invitationDesign: 15000,
  engagementPromo: 10000,
  haldiPromo: 10000,
  weddingPromo: 15000,
  receptionPromo: 10000,
  transportOutsideHyd: 25000
}

export async function GET(request: NextRequest) {
  try {
    // Test calculation with sample data
    const testData = {
      customerName: 'Test Customer',
      customerPhone: '1234567890',
      eventLocation: 'Hyderabad',
      events: {
        wedding: {
          traditionalCamera: true,
          candidPhotography: true,
          fourKVideo: true,
          ledScreens: false,
          drone: false,
          cinematicVideo: false
        }
      },
      albumSheets: '200',
      albumType: 'Light weight premium glossy albums',
      additionalServices: {
        invitationDesign: true,
        engagementPromo: false,
        haldiPromo: false,
        weddingPromo: false,
        receptionPromo: false
      },
      specialRequests: ''
    }

    let total = 0
    
    // Calculate event services
    Object.entries(testData.events).forEach(([eventKey, services]) => {
      Object.entries(services).forEach(([serviceKey, isSelected]) => {
        if (isSelected && serviceKey in PRICES) {
          total += PRICES[serviceKey as keyof typeof PRICES]
        }
      })
    })
    
    // Add albums cost
    total += PRICES.albums
    
    // Add additional services
    Object.entries(testData.additionalServices).forEach(([serviceKey, isSelected]) => {
      if (isSelected && serviceKey in PRICES) {
        total += PRICES[serviceKey as keyof typeof PRICES]
      }
    })
    
    // Add transport cost if outside Hyderabad
    if (testData.eventLocation && 
        !testData.eventLocation.toLowerCase().includes('hyderabad')) {
      total += PRICES.transportOutsideHyd
    }

    const formatPrice = (price: number) => {
      return `₹${price.toLocaleString('en-IN')}`
    }

    return NextResponse.json({
      success: true,
      testData,
      calculation: {
        eventServices: PRICES.traditionalCamera + PRICES.candidPhotography + PRICES.fourKVideo,
        albums: PRICES.albums,
        additionalServices: PRICES.invitationDesign,
        transport: 0, // Hyderabad location
        total: total
      },
      formattedTotal: formatPrice(total),
      message: 'Quotation calculation test successful'
    })

  } catch (error) {
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      message: 'Quotation calculation test failed'
    }, { status: 500 })
  }
}