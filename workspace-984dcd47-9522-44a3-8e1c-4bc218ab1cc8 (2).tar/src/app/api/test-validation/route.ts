import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    // Test validation scenarios
    const testCases = [
      {
        name: "Valid form data",
        data: {
          customerName: 'John Doe',
          customerPhone: '9876543210',
          eventLocation: 'Hyderabad'
        },
        expectedValid: true
      },
      {
        name: "Missing name",
        data: {
          customerName: '',
          customerPhone: '9876543210',
          eventLocation: 'Hyderabad'
        },
        expectedValid: false
      },
      {
        name: "Missing phone",
        data: {
          customerName: 'John Doe',
          customerPhone: '',
          eventLocation: 'Hyderabad'
        },
        expectedValid: false
      },
      {
        name: "Missing location",
        data: {
          customerName: 'John Doe',
          customerPhone: '9876543210',
          eventLocation: ''
        },
        expectedValid: false
      },
      {
        name: "All required fields missing",
        data: {
          customerName: '',
          customerPhone: '',
          eventLocation: ''
        },
        expectedValid: false
      }
    ]

    const results = testCases.map(testCase => {
      const { customerName, customerPhone, eventLocation } = testCase.data
      const isValid = !!(customerName && customerPhone && eventLocation)
      
      return {
        name: testCase.name,
        data: testCase.data,
        isValid,
        expectedValid: testCase.expectedValid,
        testPassed: isValid === testCase.expectedValid
      }
    })

    return NextResponse.json({
      success: true,
      results,
      summary: {
        total: results.length,
        passed: results.filter(r => r.testPassed).length,
        failed: results.filter(r => !r.testPassed).length
      },
      message: 'Form validation test completed'
    })

  } catch (error) {
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      message: 'Form validation test failed'
    }, { status: 500 })
  }
}