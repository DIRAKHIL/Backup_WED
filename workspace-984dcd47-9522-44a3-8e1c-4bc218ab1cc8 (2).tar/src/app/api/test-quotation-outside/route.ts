import { NextRequest, NextResponse } from 'next/server'

// Service pricing
const PRICES = {
  traditionalCamera: 15000,
  candidPhotography: 25000,
  fourKVideo: 30000,
  ledScreens: 20000,
  drone: 25000,
  cinematicVideo: 40000,
  albums: 50000,
  invitationDesign: 15000,
  engagementPromo: 10000,
  haldiPromo: 10000,
  weddingPromo: 15000,
  receptionPromo: 10000,
  transportOutsideHyd: 25000
}

export async function GET(request: NextRequest) {
  try {
    // Test calculation with sample data - outside Hyderabad
    const testData = {
      customerName: 'Test Customer',
      customerPhone: '1234567890',
      eventLocation: 'Nellore', // Outside Hyderabad
      events: {
        wedding: {
          traditionalCamera: true,
          candidPhotography: true,
          fourKVideo: true,
          ledScreens: true,
          drone: true,
          cinematicVideo: true
        },
        engagement: {
          traditionalCamera: true,
          candidPhotography: true,
          fourKVideo: false,
          ledScreens: false,
          drone: false,
          cinematicVideo: false
        }
      },
      albumSheets: '200',
      albumType: 'Light weight premium glossy albums',
      additionalServices: {
        invitationDesign: true,
        engagementPromo: true,
        haldiPromo: true,
        weddingPromo: true,
        receptionPromo: true
      },
      specialRequests: ''
    }

    let total = 0
    
    // Calculate event services
    Object.entries(testData.events).forEach(([eventKey, services]) => {
      Object.entries(services).forEach(([serviceKey, isSelected]) => {
        if (isSelected && serviceKey in PRICES) {
          total += PRICES[serviceKey as keyof typeof PRICES]
        }
      })
    })
    
    // Add albums cost
    total += PRICES.albums
    
    // Add additional services
    Object.entries(testData.additionalServices).forEach(([serviceKey, isSelected]) => {
      if (isSelected && serviceKey in PRICES) {
        total += PRICES[serviceKey as keyof typeof PRICES]
      }
    })
    
    // Add transport cost if outside Hyderabad
    let transportCost = 0
    if (testData.eventLocation && 
        !testData.eventLocation.toLowerCase().includes('hyderabad')) {
      transportCost = PRICES.transportOutsideHyd
      total += transportCost
    }

    const formatPrice = (price: number) => {
      return `₹${price.toLocaleString('en-IN')}`
    }

    return NextResponse.json({
      success: true,
      testData,
      calculation: {
        weddingServices: PRICES.traditionalCamera + PRICES.candidPhotography + PRICES.fourKVideo + PRICES.ledScreens + PRICES.drone + PRICES.cinematicVideo,
        engagementServices: PRICES.traditionalCamera + PRICES.candidPhotography,
        albums: PRICES.albums,
        additionalServices: PRICES.invitationDesign + PRICES.engagementPromo + PRICES.haldiPromo + PRICES.weddingPromo + PRICES.receptionPromo,
        transport: transportCost,
        total: total
      },
      formattedTotal: formatPrice(total),
      message: 'Quotation calculation test successful (Outside Hyderabad)'
    })

  } catch (error) {
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      message: 'Quotation calculation test failed'
    }, { status: 500 })
  }
}